// ignore_for_file: avoid_print, no_leading_underscores_for_local_identifiers, unused_element

import 'package:area2k24/Interger.dart';
import 'package:area2k24/Services.dart';
import 'package:area2k24/Setting.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_social_button/flutter_social_button.dart';
import 'package:form_field_validator/form_field_validator.dart';

class TriggerPage extends StatefulWidget {
  const TriggerPage({super.key});

  @override
  State<TriggerPage> createState() => _TriggerPageState();
}

class _TriggerPageState extends State<TriggerPage> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final _form = GlobalKey<FormState>();
  TextEditingController tmpController = TextEditingController();
  TextEditingController tempController = TextEditingController();
  TextEditingController timerController = TextEditingController();
  TextEditingController timeController = TextEditingController();
  TextEditingController textController = TextEditingController();
  final AuthServices _auth = AuthServices();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Colors.black,
      body: Wrap(
        spacing: 0.0,
        runSpacing: 0.0,
        alignment: WrapAlignment.start,
        crossAxisAlignment: WrapCrossAlignment.start,
        direction: Axis.horizontal,
        runAlignment: WrapAlignment.start,
        verticalDirection: VerticalDirection.down,
        clipBehavior: Clip.none,
        children: [
          Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Align(
                alignment: const AlignmentDirectional(-1.0, -1.0),
                child: Container(
                  width: 211.0,
                  height: 211.0,
                  decoration: BoxDecoration(
                    color: Colors.black,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: const Color.fromARGB(255, 33, 236, 243),
                    ),
                  ),
                  child: const Align(
                    alignment: AlignmentDirectional(-1.0, 0.0),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(5.0, 0.0, 0.0, 0.0),
                      child: Text(
                        'TRIGGERS \nACTIONS & REACTIONS',
                        textAlign: TextAlign.start,
                        maxLines: 2,
                        style: TextStyle(
                            fontFamily: 'Readex Pro',
                            color: Colors.white,
                            fontSize: 17.0,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              ),
              Form(
                key: _form,
                child: Align(
                  alignment: const AlignmentDirectional(0.0, 0.0),
                  child: Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(
                        0.0, 25.0, 0.0, 0.0),
                    child: Container(
                      width: 330.0,
                      height: 495.0,
                      decoration: BoxDecoration(
                        color: Colors.black,
                        border: Border.all(
                          color: const Color.fromARGB(255, 33, 236, 243),
                        ),
                      ),
                      alignment: const AlignmentDirectional(0.0, 0.0),
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            const Align(
                              alignment: AlignmentDirectional(0.0, -1.0),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 15.0, 0.0, 0.0),
                                child: Text(
                                  'ACTIONS + RÉACTION',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.white,
                                    fontSize: 23.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            Align(
                              alignment: const AlignmentDirectional(0.0, -1.0),
                              child: Padding(
                                padding: const EdgeInsetsDirectional.fromSTEB(
                                    5.0, 16.0, 0.0, 0.0),
                                child: Wrap(
                                  spacing: 2.0,
                                  runSpacing: 0.0,
                                  alignment: WrapAlignment.start,
                                  crossAxisAlignment: WrapCrossAlignment.start,
                                  direction: Axis.horizontal,
                                  runAlignment: WrapAlignment.start,
                                  verticalDirection: VerticalDirection.down,
                                  clipBehavior: Clip.none,
                                  children: [
                                    Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Align(
                                          alignment: const AlignmentDirectional(
                                              -1.0, -1.0),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(4.0, 0.0, 0.0, 0.0),
                                            child: IconButton(
                                              icon: const Icon(
                                                Icons.cloud,
                                                color: Color.fromARGB(
                                                    255, 33, 236, 243),
                                                size: 25.0,
                                              ),
                                              onPressed: () {
                                                print('IconButton pressed ...');
                                              },
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: const AlignmentDirectional(
                                              -1.0, -1.0),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(12.0, 0.0, 0.0, 0.0),
                                            child: IconButton(
                                              icon: const FaIcon(
                                                FontAwesomeIcons.spotify,
                                                color: Color.fromARGB(
                                                    255, 33, 236, 243),
                                                size: 25.0,
                                              ),
                                              onPressed: () async {
                                                _auth.spot(context);
                                              },
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: const AlignmentDirectional(
                                              0.0, 0.0),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(27.0, 0.0, 0.0, 0.0),
                                            child: SizedBox(
                                              width: 75.0,
                                              child: TextFormField(
                                                controller: tmpController,
                                                autofocus: true,
                                                obscureText: false,
                                                decoration: InputDecoration(
                                                  labelText: 'Température',
                                                  labelStyle: const TextStyle(
                                                    fontFamily: 'Readex Pro',
                                                    color: Colors.grey,
                                                    fontSize: 10.0,
                                                  ),
                                                  enabledBorder:
                                                      OutlineInputBorder(
                                                    borderSide:
                                                        const BorderSide(
                                                      color: Color.fromARGB(
                                                          255, 33, 236, 243),
                                                      width: 1.0,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                  ),
                                                  focusedBorder:
                                                      OutlineInputBorder(
                                                    borderSide:
                                                        const BorderSide(
                                                      color: Color.fromARGB(
                                                          255, 33, 236, 243),
                                                      width: 1.0,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                  ),
                                                  errorBorder:
                                                      OutlineInputBorder(
                                                    borderSide:
                                                        const BorderSide(
                                                      color: Color.fromARGB(
                                                          255, 33, 236, 243),
                                                      width: 1.0,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                  ),
                                                  focusedErrorBorder:
                                                      OutlineInputBorder(
                                                    borderSide:
                                                        const BorderSide(
                                                      color: Color.fromARGB(
                                                          255, 33, 236, 243),
                                                      width: 1.0,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                  ),
                                                ),
                                                style: const TextStyle(
                                                  fontFamily: 'Readex Pro',
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                                keyboardType:
                                                    TextInputType.number,
                                                cursorColor:
                                                    const Color.fromARGB(
                                                        255, 33, 236, 243),
                                                validator: MultiValidator([
                                                  RequiredValidator(
                                                      errorText: "Enter value"),
                                                ]),
                                                inputFormatters: [
                                                  FilteringTextInputFormatter
                                                      .allow(RegExp('[0-9]'))
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: const AlignmentDirectional(
                                              1.0, 0.0),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(50.0, 0.0, 0.0, 0.0),
                                            child: IconButton(
                                              icon: const Icon(
                                                Icons.play_arrow,
                                                color: Color.fromARGB(
                                                    255, 33, 236, 243),
                                                size: 25.0,
                                              ),
                                              onPressed: () {
                                                _auth.startAuthentication(
                                                    context);
                                              },
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              0.0, 15.0, 0.0, 0.0),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    -1.0, -1.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      4.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const Icon(
                                                  Icons.access_time_filled,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print(
                                                      'IconButton pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    -1.0, -1.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      12.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const FaIcon(
                                                  FontAwesomeIcons.spotify,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print(
                                                      'IconButton pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    0.0, 0.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      27.0, 0.0, 0.0, 0.0),
                                              child: SizedBox(
                                                width: 75.0,
                                                child: TextFormField(
                                                  controller: timerController,
                                                  autofocus: true,
                                                  obscureText: false,
                                                  decoration: InputDecoration(
                                                    labelText: 'Minutes',
                                                    labelStyle: const TextStyle(
                                                      fontFamily: 'Readex Pro',
                                                      color: Colors.grey,
                                                      fontSize: 10.0,
                                                    ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                    focusedBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                    errorBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                    focusedErrorBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                  ),
                                                  style: const TextStyle(
                                                    fontFamily: 'Readex Pro',
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  keyboardType:
                                                      TextInputType.number,
                                                  cursorColor: Colors.white,
                                                  validator: MultiValidator([
                                                    RequiredValidator(
                                                        errorText:
                                                            "Enter value"),
                                                  ]),
                                                  inputFormatters: [
                                                    FilteringTextInputFormatter
                                                        .allow(RegExp('[0-9]'))
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    1.0, 0.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      50.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const Icon(
                                                  Icons.play_arrow,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print('trigger2 pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              0.0, 15.0, 0.0, 0.0),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    -1.0, -1.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      4.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const Icon(
                                                  Icons.cloud,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print(
                                                      'IconButton pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    -1.0, -1.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      12.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const FaIcon(
                                                  FontAwesomeIcons.linkedin,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print(
                                                      'IconButton pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    0.0, 0.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      27.0, 0.0, 0.0, 0.0),
                                              child: SizedBox(
                                                width: 75.0,
                                                child: TextFormField(
                                                  controller: tempController,
                                                  autofocus: true,
                                                  obscureText: false,
                                                  decoration: InputDecoration(
                                                    labelText: 'Minutes',
                                                    labelStyle: const TextStyle(
                                                      fontFamily: 'Readex Pro',
                                                      color: Colors.grey,
                                                      fontSize: 10.0,
                                                    ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                    focusedBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                    errorBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                    focusedErrorBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                  ),
                                                  style: const TextStyle(
                                                    fontFamily: 'Readex Pro',
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  keyboardType:
                                                      TextInputType.number,
                                                  cursorColor: Colors.white,
                                                  validator: MultiValidator([
                                                    RequiredValidator(
                                                        errorText:
                                                            "Enter value"),
                                                  ]),
                                                  inputFormatters: [
                                                    FilteringTextInputFormatter
                                                        .allow(RegExp('[0-9]'))
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    1.0, 0.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      50.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const Icon(
                                                  Icons.play_arrow,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print('trigger3 pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              0.0, 15.0, 0.0, 0.0),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    -1.0, -1.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      4.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const Icon(
                                                  Icons.access_time_filled,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print(
                                                      'IconButton pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    -1.0, -1.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      12.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const FaIcon(
                                                  FontAwesomeIcons.linkedin,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print(
                                                      'IconButton pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    -1.0, 0.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      14.0, 0.0, 0.0, 0.0),
                                              child: SizedBox(
                                                width: 60.0,
                                                child: TextFormField(
                                                  controller: timeController,
                                                  autofocus: true,
                                                  obscureText: false,
                                                  decoration: InputDecoration(
                                                    labelText: 'Minutes',
                                                    labelStyle: const TextStyle(
                                                      fontFamily: 'Readex Pro',
                                                      color: Colors.grey,
                                                      fontSize: 10.0,
                                                    ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                    focusedBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                    errorBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                    focusedErrorBorder:
                                                        OutlineInputBorder(
                                                      borderSide:
                                                          const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 33, 236, 243),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                    ),
                                                  ),
                                                  style: const TextStyle(
                                                    fontFamily: 'Readex Pro',
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  keyboardType:
                                                      TextInputType.number,
                                                  cursorColor: Colors.white,
                                                  validator: MultiValidator([
                                                    RequiredValidator(
                                                        errorText:
                                                            "Enter value"),
                                                  ]),
                                                  inputFormatters: [
                                                    FilteringTextInputFormatter
                                                        .allow(RegExp('[0-9]'))
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          Expanded(
                                            child: Align(
                                              alignment:
                                                  const AlignmentDirectional(
                                                      -1.0, 0.0),
                                              child: Padding(
                                                padding:
                                                    const EdgeInsetsDirectional
                                                        .fromSTEB(
                                                        10.0, 0.0, 0.0, 0.0),
                                                child: SizedBox(
                                                  width: 70.0,
                                                  child: TextFormField(
                                                    controller: textController,
                                                    autofocus: true,
                                                    obscureText: false,
                                                    decoration: InputDecoration(
                                                      labelText: 'Minutes',
                                                      labelStyle:
                                                          const TextStyle(
                                                        fontFamily:
                                                            'Readex Pro',
                                                        color: Colors.grey,
                                                        fontSize: 10.0,
                                                      ),
                                                      hintText: 'Texte',
                                                      hintStyle:
                                                          const TextStyle(
                                                        fontFamily:
                                                            'Readex Pro',
                                                        fontSize: 12.0,
                                                      ),
                                                      enabledBorder:
                                                          OutlineInputBorder(
                                                        borderSide:
                                                            const BorderSide(
                                                          color: Color.fromARGB(
                                                              255,
                                                              33,
                                                              236,
                                                              243),
                                                          width: 1.0,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5.0),
                                                      ),
                                                      focusedBorder:
                                                          OutlineInputBorder(
                                                        borderSide:
                                                            const BorderSide(
                                                          color: Color.fromARGB(
                                                              255,
                                                              33,
                                                              236,
                                                              243),
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5.0),
                                                      ),
                                                      errorBorder:
                                                          OutlineInputBorder(
                                                        borderSide:
                                                            const BorderSide(
                                                          color: Color.fromARGB(
                                                              255,
                                                              33,
                                                              236,
                                                              243),
                                                          width: 1.0,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5.0),
                                                      ),
                                                      focusedErrorBorder:
                                                          OutlineInputBorder(
                                                        borderSide:
                                                            const BorderSide(
                                                          color: Color.fromARGB(
                                                              255,
                                                              33,
                                                              236,
                                                              243),
                                                          width: 1.0,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5.0),
                                                      ),
                                                    ),
                                                    style: const TextStyle(
                                                      fontFamily: 'Readex Pro',
                                                      color: Colors.white,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                    cursorColor: Colors.white,
                                                    validator: MultiValidator([
                                                      RequiredValidator(
                                                          errorText:
                                                              "Enter value"),
                                                    ]),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    1.0, 0.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      0.0, 0.0, 18.0, 0.0),
                                              child: IconButton(
                                                icon: const Icon(
                                                  Icons.play_arrow,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print('trigger4 pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              0.0, 15.0, 0.0, 0.0),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    -1.0, -1.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      4.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const FaIcon(
                                                  FontAwesomeIcons.gitlab,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print(
                                                      'gitlabicon pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    -1.0, -1.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      12.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const FaIcon(
                                                  FontAwesomeIcons.gitlab,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print(
                                                      'IconButton pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                          const Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    20.0, 0.0, 0.0, 0.0),
                                            child: Text(
                                              'PUSH + MAIL',
                                              style: TextStyle(
                                                fontFamily: 'Readex Pro',
                                                fontWeight: FontWeight.bold,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    1.0, 0.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      39.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const Icon(
                                                  Icons.play_arrow,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print('trigger5 pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              0.0, 15.0, 0.0, 0.0),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    -1.0, -1.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      4.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const FaIcon(
                                                  FontAwesomeIcons.gitlab,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print(
                                                      'gitlabicon pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    -1.0, -1.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      12.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const FaIcon(
                                                  FontAwesomeIcons.gitlab,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print(
                                                      'IconButton pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                          const Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    20.0, 0.0, 0.0, 0.0),
                                            child: Text(
                                              'MERGE REQUEST',
                                              style: TextStyle(
                                                fontFamily: 'Readex Pro',
                                                fontWeight: FontWeight.bold,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(
                                                    1.0, 0.0),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      12.0, 0.0, 0.0, 0.0),
                                              child: IconButton(
                                                icon: const Icon(
                                                  Icons.play_arrow,
                                                  color: Color.fromARGB(
                                                      255, 33, 236, 243),
                                                  size: 25.0,
                                                ),
                                                onPressed: () {
                                                  print('trigger5 pressed ...');
                                                },
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          Align(
            alignment: const AlignmentDirectional(0.0, 1.0),
            child: Padding(
              padding:
                  const EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
              child: Container(
                width: 148.0,
                height: 41.0,
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(20.0),
                  border: Border.all(
                    color: const Color.fromARGB(255, 33, 236, 243),
                    width: 2.0,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Align(
                      alignment: const AlignmentDirectional(-1.0, 0.0),
                      child: IconButton(
                        icon: const Icon(
                          Icons.home,
                          color: Color.fromARGB(255, 33, 236, 243),
                          size: 23.0,
                        ),
                        onPressed: () async {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const HomeService()));
                        },
                      ),
                    ),
                    Align(
                      alignment: const AlignmentDirectional(-1.0, 0.0),
                      child: IconButton(
                          icon: const Icon(
                            Icons.settings,
                            color: Color.fromARGB(255, 33, 236, 243),
                            size: 23.0,
                          ),
                          onPressed: () async {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const Setting()));
                          }),
                    ),
                    Align(
                      alignment: const AlignmentDirectional(1.0, 0.0),
                      child: IconButton(
                        icon: const Icon(
                          Icons.logout,
                          color: Color.fromARGB(255, 33, 236, 243),
                          size: 23.0,
                        ),
                        onPressed: () {
                          print('logouticon pressed ...');
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
