// ignore_for_file: depend_on_referenced_packages, avoid_print, use_build_context_synchronously

import 'package:area2k24/Interger.dart';
import 'package:area2k24/SignUp.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _form = GlobalKey<FormState>();
  final AuthServices _auth = AuthServices();
  TextEditingController emailControler = TextEditingController();
  TextEditingController passwordControler = TextEditingController();
  bool _passwordVisible = false;

  String? validatePassword(String value) {
    if (value.isEmpty) {
      return "* Required";
    } else if (value.length < 6) {
      return "Password should be atleast 6 characters";
    } else if (value.length > 15) {
      return "Password should not be greater than 15 characters";
    } else {
      return null;
    }
  }

  String? validateEmail(String value) {
    // ignore: unnecessary_null_comparison
    if (value == null || value.isEmpty) {
      return 'Entrez votre Email';
    } else if (!RegExp(r'\S+@\S+\.\S+').hasMatch(value)) {
      return "Please enter a valid email address";
    } else {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
          child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          const Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 150.0, 0.0, 0.0),
              child: Text(
                'AREA PROJECT',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Readex Pro',
                  color: Color.fromARGB(255, 33, 236, 243),
                  fontSize: 26.0,
                ),
              ),
            ),
          ),
          Form(
            key: _form,
            child: Align(
              alignment: const AlignmentDirectional(0.0, 0.0),
              child: Padding(
                padding:
                    const EdgeInsetsDirectional.fromSTEB(0.0, 35.0, 0.0, 0.0),
                child: Container(
                  width: 298.0,
                  height: 374.0,
                  decoration: BoxDecoration(
                    color: Colors.black,
                    border: Border.all(
                      color: const Color.fromARGB(255, 33, 236, 243),
                    ),
                  ),
                  alignment: const AlignmentDirectional(0.0, 0.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      const Align(
                        alignment: AlignmentDirectional(0.0, -1.0),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 20.0, 0.0, 0.0),
                          child: Text(
                            'Sign in',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontFamily: 'Readex Pro',
                              color: Color.fromARGB(255, 33, 236, 243),
                              fontSize: 24.0,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsetsDirectional.fromSTEB(
                            0.0, 20.0, 0.0, 0.0),
                        child: Wrap(
                          spacing: 2.0,
                          runSpacing: 0.0,
                          alignment: WrapAlignment.start,
                          crossAxisAlignment: WrapCrossAlignment.start,
                          direction: Axis.horizontal,
                          runAlignment: WrapAlignment.start,
                          verticalDirection: VerticalDirection.down,
                          clipBehavior: Clip.none,
                          children: [
                            const Align(
                              alignment: AlignmentDirectional(-1.0, -1.0),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    12.0, 8.0, 0.0, 0.0),
                                child: Text(
                                  'Email',
                                  style: TextStyle(
                                    fontFamily: 'Readex Pro',
                                    color: Color.fromARGB(255, 33, 236, 243),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  8.0, 0.0, 8.0, 0.0),
                              child: TextFormField(
                                validator: MultiValidator([
                                  RequiredValidator(
                                      errorText: "Email adress is required"),
                                  EmailValidator(
                                      errorText: "Invalid Email retry")
                                ]),
                                controller: emailControler,
                                autofocus: true,
                                obscureText: false,
                                decoration: InputDecoration(
                                  labelStyle: const TextStyle(
                                      fontFamily: 'Readex Pro',
                                      color: Colors.white),
                                  alignLabelWithHint: false,
                                  hintText: 'Email adress',
                                  hintStyle:
                                      const TextStyle(color: Colors.grey),
                                  enabledBorder: UnderlineInputBorder(
                                    borderSide: const BorderSide(
                                      color: Color.fromARGB(255, 33, 236, 243),
                                      width: 4.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  focusedBorder: UnderlineInputBorder(
                                    borderSide: const BorderSide(
                                      color: Color.fromARGB(255, 33, 236, 243),
                                      width: 4.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  errorBorder: UnderlineInputBorder(
                                    borderSide: const BorderSide(
                                      color: Colors.red,
                                      width: 4.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  focusedErrorBorder: UnderlineInputBorder(
                                    borderSide: const BorderSide(
                                      color: Colors.red,
                                      width: 4.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  contentPadding:
                                      const EdgeInsetsDirectional.fromSTEB(
                                          4.0, 0.0, 0.0, 0.0),
                                ),
                                style: const TextStyle(color: Colors.white),
                                textAlign: TextAlign.start,
                                keyboardType: TextInputType.emailAddress,
                                cursorColor:
                                    const Color.fromARGB(255, 33, 236, 243),
                              ),
                            ),
                            const Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  12.0, 25.0, 0.0, 0.0),
                              child: Text(
                                'Password',
                                style: TextStyle(
                                  fontFamily: 'Readex Pro',
                                  color: Color.fromARGB(255, 33, 236, 243),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  8.0, 0.0, 8.0, 0.0),
                              child: TextFormField(
                                validator: MultiValidator([
                                  RequiredValidator(
                                      errorText: "Password is required"),
                                  MinLengthValidator(6,
                                      errorText:
                                          "Password should be 6 character"),
                                  MaxLengthValidator(15,
                                      errorText: "Less than 15 character")
                                ]),
                                controller: passwordControler,
                                autofocus: true,
                                obscureText: !_passwordVisible,
                                decoration: InputDecoration(
                                  hintText: 'Password here',
                                  suffixIcon: IconButton(
                                    icon: Icon(
                                      _passwordVisible
                                          ? Icons.visibility
                                          : Icons.visibility_off,
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        _passwordVisible = !_passwordVisible;
                                      });
                                    },
                                  ),
                                  hintStyle:
                                      const TextStyle(color: Colors.grey),
                                  enabledBorder: UnderlineInputBorder(
                                    borderSide: const BorderSide(
                                      color: Color.fromARGB(255, 33, 236, 243),
                                      width: 4.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  focusedBorder: UnderlineInputBorder(
                                    borderSide: const BorderSide(
                                      color: Color.fromARGB(255, 33, 236, 243),
                                      width: 4.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  errorBorder: UnderlineInputBorder(
                                    borderSide: const BorderSide(
                                      color: Colors.red,
                                      width: 4.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  focusedErrorBorder: UnderlineInputBorder(
                                    borderSide: const BorderSide(
                                      color: Colors.red,
                                      width: 4.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  contentPadding:
                                      const EdgeInsetsDirectional.fromSTEB(
                                          4.0, 16.0, 0.0, 0.0),
                                ),
                                style: const TextStyle(color: Colors.white),
                                keyboardType: TextInputType.visiblePassword,
                                cursorColor:
                                    const Color.fromARGB(255, 33, 236, 243),
                              ),
                            ),
                            const Align(
                              alignment: AlignmentDirectional(-1.0, 0.0),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    12.0, 5.0, 0.0, 0.0),
                                child: Text('Forget password ?',
                                    style: TextStyle(color: Colors.grey)),
                              ),
                            ),
                            Align(
                              alignment: const AlignmentDirectional(-1.0, 0.0),
                              child: Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      85.0, 20.0, 0.0, 0.0),
                                  child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                          backgroundColor: const Color.fromARGB(
                                              255, 33, 236, 243),
                                          shadowColor: const Color.fromARGB(
                                              0, 95, 210, 227),
                                          elevation: 10,
                                          animationDuration:
                                              const Duration(milliseconds: 10)),
                                      onPressed: () async {
                                        if (_form.currentState!.validate()) {
                                          print("Validated");
                                          var response = _auth.register(
                                              context,
                                              emailControler.text,
                                              passwordControler.text);
                                          print(response);
                                        } else {
                                          print("Not Validated");
                                        }
                                      },
                                      child: const Text(
                                        "LOG IN",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 24,
                                            fontWeight: FontWeight.bold),
                                      ))),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Align(
            alignment: const AlignmentDirectional(-1.0, 1.0),
            child: Padding(
              padding:
                  const EdgeInsetsDirectional.fromSTEB(95.0, 10.0, 0.0, 0.0),
              child: InkWell(
                splashColor: Colors.transparent,
                focusColor: Colors.transparent,
                hoverColor: Colors.transparent,
                highlightColor: Colors.transparent,
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const SignUpPage())),
                child: const Text(
                  'Sign Up',
                  style: TextStyle(
                    fontSize: 20,
                    fontFamily: 'Readex Pro',
                    color: Color.fromARGB(255, 33, 236, 243),
                  ),
                ),
              ),
            ),
          ),
        ],
      )),
    );
  }
}