// ignore_for_file: avoid_print, no_leading_underscores_for_local_identifiers, use_build_context_synchronously

import 'package:area2k24/Setting.dart';
import 'package:area2k24/Trigger.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class HomeService extends StatefulWidget {
  const HomeService({super.key});

  @override
  State<HomeService> createState() => _HomeServiceState();
}

class _HomeServiceState extends State<HomeService> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  //final AuthServices _auth = AuthServices();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Colors.black,
      body: Wrap(
        spacing: 0.0,
        runSpacing: 0.0,
        alignment: WrapAlignment.start,
        crossAxisAlignment: WrapCrossAlignment.start,
        direction: Axis.horizontal,
        runAlignment: WrapAlignment.start,
        verticalDirection: VerticalDirection.down,
        clipBehavior: Clip.none,
        children: [
          Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Align(
                alignment: const AlignmentDirectional(-1.0, -1.0),
                child: Container(
                  width: 211.0,
                  height: 211.0,
                  decoration: const BoxDecoration(
                    color: Color.fromARGB(255, 33, 236, 243),
                    shape: BoxShape.circle,
                  ),
                  child: const Align(
                    alignment: AlignmentDirectional(1.0, 0.0),
                    child: Text(
                      'AREA PROJECT',
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      style: TextStyle(
                        fontFamily: 'Readex Pro',
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 25.0,
                      ),
                    ),
                  ),
                ),
              ),
              Align(
                alignment: const AlignmentDirectional(0.0, 0.0),
                child: Padding(
                  padding:
                      const EdgeInsetsDirectional.fromSTEB(0.0, 25.0, 0.0, 0.0),
                  child: Container(
                    width: 330.0,
                    height: 495.0,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      border: Border.all(
                        color: const Color.fromARGB(255, 33, 236, 243),
                      ),
                    ),
                    alignment: const AlignmentDirectional(0.0, 0.0),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          const Align(
                            alignment: AlignmentDirectional(0.0, -1.0),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              child: Text(
                                'SERVICES',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Readex Pro',
                                  color: Colors.white,
                                  fontSize: 24.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: const AlignmentDirectional(0.0, -1.0),
                            child: Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  0.0, 16.0, 0.0, 0.0),
                              child: Wrap(
                                spacing: 2.0,
                                runSpacing: 0.0,
                                alignment: WrapAlignment.start,
                                crossAxisAlignment: WrapCrossAlignment.start,
                                direction: Axis.vertical,
                                runAlignment: WrapAlignment.start,
                                verticalDirection: VerticalDirection.down,
                                clipBehavior: Clip.none,
                                children: [
                                  Align(
                                    alignment:
                                        const AlignmentDirectional(0.0, -1.0),
                                    child: Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              30.0, 0.0, 0.0, 0.0),
                                      child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                const Color.fromARGB(
                                                    255, 33, 236, 243),
                                            shadowColor: const Color.fromARGB(
                                                0, 95, 210, 227),
                                            elevation: 10,
                                            animationDuration: const Duration(
                                                milliseconds: 10)),
                                        onPressed: () {
                                          launchUrl(Uri.parse(
                                              "https://accounts.spotify.com/authorize?client_id=53a74d8b4e4f4864aa6a87f3e6622e41&response_type=code&redirect_uri=http%3A%2F%2F127.0.0.1%3A8000%2Fauth%2Fspotify%2Fcallback%2F&scope=playlist-modify-private+playlist-modify-public+playlist-read-private+user-library-modify+user-library-read+user-modify-playback-state+user-read-playback-state+user-read-private+user-read-private"));
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      const TriggerPage()));
                                        },
                                        child: const Text(
                                          "Spotify",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 24,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment:
                                        const AlignmentDirectional(0.0, -1.0),
                                    child: Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              30.0, 0.0, 0.0, 0.0),
                                      child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                const Color.fromARGB(
                                                    255, 33, 236, 243),
                                            shadowColor: const Color.fromARGB(
                                                0, 95, 210, 227),
                                            elevation: 10,
                                            animationDuration: const Duration(
                                                milliseconds: 10)),
                                        onPressed: () {
                                          launchUrl(Uri.parse(
                                              "https://www.linkedin.com/uas/oauth2/authorization?response_type=code&client_id=78ffdiofzcorb6&scope=r_liteprofile%20r_emailaddress%20w_member_social&state=6205222473eb7cfcdadc78c7e2481b88&redirect_uri=http%3A//127.0.0.1%3A8000/auth/linkedin-callback/"));
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      const TriggerPage()));
                                        },
                                        child: const Text(
                                          "Linkedin",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 24,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment:
                                        const AlignmentDirectional(0.0, -1.0),
                                    child: Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              30.0, 0.0, 0.0, 0.0),
                                      child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                const Color.fromARGB(
                                                    255, 33, 236, 243),
                                            shadowColor: const Color.fromARGB(
                                                0, 95, 210, 227),
                                            elevation: 10,
                                            animationDuration: const Duration(
                                                milliseconds: 10)),
                                        onPressed: () {
                                          launchUrl(Uri.parse(
                                              "https://shalom9.pythonanywhere.com/auth/gitlab-auth/"));
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      const TriggerPage()));
                                        },
                                        child: const Text(
                                          "Gitlab",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 24,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment:
                                        const AlignmentDirectional(0.0, -1.0),
                                    child: Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              30.0, 0.0, 0.0, 0.0),
                                      child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                const Color.fromARGB(
                                                    255, 33, 236, 243),
                                            shadowColor: const Color.fromARGB(
                                                0, 95, 210, 227),
                                            elevation: 10,
                                            animationDuration: const Duration(
                                                milliseconds: 10)),
                                        onPressed: () {},
                                        child: const Text(
                                          "Timer",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 24,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment:
                                        const AlignmentDirectional(0.0, -1.0),
                                    child: Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              30.0, 0.0, 0.0, 0.0),
                                      child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                const Color.fromARGB(
                                                    255, 33, 236, 243),
                                            shadowColor: const Color.fromARGB(
                                                0, 95, 210, 227),
                                            elevation: 10,
                                            animationDuration: const Duration(
                                                milliseconds: 10)),
                                        onPressed: () {},
                                        child: const Text(
                                          "Weather",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 24,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          Align(
            alignment: const AlignmentDirectional(0.0, 1.0),
            child: Padding(
              padding:
                  const EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
              child: Container(
                width: 149.0,
                height: 41.0,
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(20.0),
                  border: Border.all(
                    color: const Color.fromARGB(255, 33, 236, 243),
                    width: 2.0,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Align(
                      alignment: const AlignmentDirectional(-1.0, -1.0),
                      child: IconButton(
                        icon: const Icon(
                          Icons.settings,
                          color: Color.fromARGB(255, 33, 236, 243),
                          size: 23.0,
                        ),
                        onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Setting())),
                      ),
                    ),
                    Align(
                      alignment: const AlignmentDirectional(-1.0, 0.0),
                      child: IconButton(
                        icon: const Icon(
                          Icons.play_circle,
                          color: Color.fromARGB(255, 33, 236, 243),
                          size: 23.0,
                        ),
                        onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const TriggerPage())),
                      ),
                    ),
                    Align(
                      alignment: const AlignmentDirectional(1.0, 0.0),
                      child: IconButton(
                        icon: const Icon(
                          Icons.logout,
                          color: Color.fromARGB(255, 33, 236, 243),
                          size: 23.0,
                        ),
                        onPressed: () {
                          print('logoutbutton pressed ...');
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
