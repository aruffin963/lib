import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

const url =
    "https://";

launchurl(BuildContext context) async {
  final uri = Uri.parse(url);
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri);

    // ignore: use_build_context_synchronously
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => Container()));
  } else {
    throw 'Could not launch $url';
  }
}

void spotifyauth(BuildContext context) async {
  var urll = Uri.parse(url);
  var res = await http.post(urll);
  // log.i(res.body);
  if (res.statusCode == 200) {
    // ignore: use_build_context_synchronously
    await launchurl(context);
  } else if (res.statusCode == 500) {
    // ignore: avoid_print
    print("Unbound local error");
  }
}