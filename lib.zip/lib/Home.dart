// ignore_for_file: depend_on_referenced_packages, avoid_print, use_build_context_synchronously

import 'package:area2k24/SignUp.dart';
import 'package:area2k24/Trigger.dart';
import 'package:flutter/material.dart';
import 'package:animated_text_kit/animated_text_kit.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          children: [
            const SizedBox(
              height: 400,
            ),
            SizedBox(
              width: 350.0,
              child: DefaultTextStyle(
                style: const TextStyle(
                  fontSize: 30.0,
                  fontFamily: 'Agne',
                ),
                child: AnimatedTextKit(
                  isRepeatingAnimation: false,
                  animatedTexts: [
                    TypewriterAnimatedText('   Welcome on AREA '),
                    TypewriterAnimatedText('Automatise your life now'),
                    TypewriterAnimatedText('     Sign In to continue'),
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 300,
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  shadowColor: const Color.fromARGB(0, 95, 210, 227),
                  elevation: 10,
                  animationDuration: const Duration(milliseconds: 10)),
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const TriggerPage())),
              child: const Text(
                "S'INSCRIRE",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
