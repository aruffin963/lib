// ignore_for_file: depend_on_referenced_packages, avoid_print, use_build_context_synchronously, no_leading_underscores_for_local_identifiers, unused_element, deprecated_member_use, unnecessary_null_comparison

import 'dart:convert';
import 'package:area2k24/Services.dart';
import 'package:area2k24/Trigger.dart';
import 'package:http/http.dart' as http;
import 'package:logger/logger.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_web_auth/flutter_web_auth.dart';

class AuthServices {
  Future<String> registration(BuildContext context, String username,
      String email, String password) async {
    Map<String, String> body = {
      "username": username,
      "email": email,
      "password": password
    };
    var log = Logger();
    log.d(body);
    var response = await http.post(
        Uri.parse("https://shalom9.pythonanywhere.com/auth/register/"),
        body: body);
    log.i(response.body);
    if (response.statusCode == 200 || response.statusCode == 201) {
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => const HomeService()));
      return jsonEncode(response.body);
    } else if (response.statusCode == 500) {
      return ("Internal Server");
    }
    return response.body;
  }

  Future<String> register(
      BuildContext context, String email, String password) async {
    Map<String, String> body = {"email": email, "password": password};
    var log = Logger();
    log.d(body);
    var response = await http.post(
        Uri.parse("https://shalom9.pythonanywhere.com/auth/login/"),
        body: body);
    log.i(response.body);
    if (response.statusCode == 200 || response.statusCode == 201) {
// -------> Ici tu dois mettre la route vers la nouvelle page tu vas juste mettre const le nom de la page
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => const HomeService()));
    } else if (response.statusCode == 500) {
      return ("Internal Server");
    }
    return response.body;
  }

  Future<String> spot(BuildContext context) async {
    var response = await http
        .get(Uri.parse("https://shalom9.pythonanywhere.com/auth/spotify/me/"));
    if (response.statusCode == 200 || response.statusCode == 201) {
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => const TriggerPage()));
    } else if (response.statusCode == 500) {
      return ("Internal Server");
    }
    return response.body;
  }

  Future<void> startAuthentication(BuildContext context) async {
    const String clientId = "53a74d8b4e4f4864aa6a87f3e6622e41";
    const String redirectUri =
        "https://shalom9.pythonanywhere.com/auth/spotify/me/"; // e.g., com.example.your_app://callback
    const String scopes =
        "user-read-private user-read-email playlist-modify-public";
    final String authUrl =
        "https://accounts.spotify.com/authorize?client_id=$clientId&response_type=code&redirect_uri=$redirectUri&scope=$scopes";

    try {
      final result = await FlutterWebAuth.authenticate(
          url: authUrl, callbackUrlScheme: redirectUri);

      if (result != null && result.isNotEmpty) {
        final code = result.substring(result.indexOf('=') + 1);
        // Now you can use the 'code' to get an access token
        // You may need to make an HTTP request to your server or Spotify's token endpoint
        print(code);
        var response = await http.get(Uri.parse(
            "https://shalom9.pythonanywhere.com/auth/spotify/callback/"));
        if (response.statusCode == 200 || response.statusCode == 201) {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => const TriggerPage()));
        } else if (response.statusCode == 500) {
          print("error");
        }
      }
    } catch (e) {
      print("Authentication error: $e");
    }
  }
}

void launchSpotifyAuthUrl() async {
  const authUrl =
      "https://accounts.spotify.com/authorize?client_id=53a74d8b4e4f4864aa6a87f3e6622e41&response_type=code&redirect_uri=http%3A%2F%2F127.0.0.1%3A8000%2Fauth%2Fspotify%2Fcallback%2F&scope=playlist-modify-private+playlist-modify-public+playlist-read-private+user-library-modify+user-library-read+user-modify-playback-state+user-read-playback-state+user-read-private+user-read-private";
  if (await canLaunch(authUrl)) {
    await launch(authUrl);
  } else {
    print('Could not launch $authUrl');
  }
}
