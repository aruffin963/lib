// ignore_for_file: depend_on_referenced_packages, avoid_print, use_build_context_synchronously, no_leading_underscores_for_local_identifiers, unused_element, deprecated_member_use, unnecessary_null_comparison

import 'dart:convert';
import 'package:area2k24/Services.dart';
import 'package:area2k24/Trigger.dart';
import 'package:http/http.dart' as http;
import 'package:logger/logger.dart';
import 'package:flutter/material.dart';

class AuthServices {
  Future<String> registration(BuildContext context, String username,
      String email, String password) async {
    Map<String, String> body = {
      "username": username,
      "email": email,
      "password": password
    };
    var log = Logger();
    log.d(body);
    var response = await http.post(
        Uri.parse("https://shalom9.pythonanywhere.com/auth/register/"),
        body: body);
    log.i(response.body);
    if (response.statusCode == 200 || response.statusCode == 201) {
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => const HomeService()));
      return jsonEncode(response.body);
    } else if (response.statusCode == 500) {
      return ("Internal Server");
    }
    return response.body;
  }

  Future<String> register(
      BuildContext context, String email, String password) async {
    Map<String, String> body = {"email": email, "password": password};
    var log = Logger();
    log.d(body);
    var response = await http.post(
        Uri.parse("https://shalom9.pythonanywhere.com/auth/login/"),
        body: body);
    log.i(response.body);
    if (response.statusCode == 200 || response.statusCode == 201) {
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => const HomeService()));
    } else if (response.statusCode == 500) {
      return ("Internal Server");
    }
    return response.body;
  }

  Future<String> spot(BuildContext context) async {
    var response = await http
        .get(Uri.parse("https://shalom9.pythonanywhere.com/auth/spotify/me/"));
    if (response.statusCode == 200 || response.statusCode == 201) {
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => const TriggerPage()));
    } else if (response.statusCode == 500) {
      return ("Internal Server");
    }
    return response.body;
  }

}